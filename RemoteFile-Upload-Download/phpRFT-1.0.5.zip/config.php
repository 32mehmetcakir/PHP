<?php
if(!defined("phpRFT")) exit("access denied!");
define("DownloadFolder", "downloads");
define("TimeLimit", 0);
define("MemoryLimit", "500M");
?>